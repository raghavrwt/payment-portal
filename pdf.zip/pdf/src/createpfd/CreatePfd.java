package createpfd;

import java.io.FileOutputStream;
import java.util.Date;
import java.util.function.DoubleConsumer;

import com.itextpdf.text.Chapter;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Section;
import com.itextpdf.text.TabStop.Alignment;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class CreatePfd {

	public void createPdf(String userName, String policyName, String policyType, String policyCost, String summary ) {
		
		Document document = null;
		PdfWriter writer = null ;
		
		try
	    {
			 document = new Document(PageSize.A4);

			 writer = PdfWriter.getInstance(document, new FileOutputStream("HelloWorld.pdf"));
			 
			 /*//password protection
			 writer.setEncryption("concretepage".getBytes(), "cp123".getBytes(), PdfWriter.ALLOW_COPY, PdfWriter.STANDARD_ENCRYPTION_40);
		     writer.createXmpMetadata();
			 */
			 
			 
	         document.open();
	         
	         //adding default attributes to pdf file
	         document.addCreationDate();
	         document.addAuthor("Insta Insurance");
	         document.addTitle("Payment Receipt");
	         document.addSubject("Payment Receipt for Policy from Insta Insurance");
	         
	         
	         
	         
	         //Company Name
	         Paragraph companyName = new Paragraph("Insta Insurance",FontFactory.getFont(
	        		 													FontFactory.TIMES_BOLD, 24, Font.NORMAL,
	        		 													new CMYKColor(255, 255, 255, 255) ) );
	        
	         
	         
	         

	        		
	        		
	         Paragraph address = new Paragraph("227 Cobblestone Road, 30000 Bedrock, Cobblestone County", 
	        				 
	         FontFactory.getFont(FontFactory.HELVETICA, 9, Font.NORMAL, new CMYKColor(255, 255, 255,255)));
	        		
	         Paragraph contactDetails = new Paragraph("Phone: +1 780 546 2222, Fax: +1 780 546 2424", 
	        				 
	         FontFactory.getFont(FontFactory.HELVETICA, 9, Font.NORMAL, 
	        			    
	        			       new CMYKColor(255, 255, 255,255)));
	        		
	         Paragraph webDetails = new Paragraph("Website: www.InstaInsurance.com, Email: CustomerSupport@InstaInsurance.com", 
	        				 
	         FontFactory.getFont(FontFactory.HELVETICA, 9, Font.NORMAL, 
	        			    
	        			       new CMYKColor(255, 255, 255,255)));
	        		
	        		
	        	
	        	//printing current date
	         Date date =  new Date();
	       	 Paragraph dateParagraph = new Paragraph("Date : " + date.getDate() + "/" + date.getMonth() + "/" + date.getYear()  );

	         
	         
	         
	         

	         
	         
	         
	       	PdfPTable table = new PdfPTable(4);
	        
	       	// set the width of the table to 100% of page
	        table.setWidthPercentage(100);
	       	
	        PdfPCell c1 = new PdfPCell(new Phrase("User Name"));
	        c1.setHorizontalAlignment(Element.ALIGN_LEFT);
	        table.addCell(c1);

	        c1 = new PdfPCell(new Phrase("Policy Name"));
	        c1.setHorizontalAlignment(Element.ALIGN_LEFT);
	        table.addCell(c1);

	        c1 = new PdfPCell(new Phrase("Policy Type"));
	        c1.setHorizontalAlignment(Element.ALIGN_LEFT);
	        table.addCell(c1);
	        
	        c1 = new PdfPCell(new Phrase("Policy Cost"));
	        c1.setHorizontalAlignment(Element.ALIGN_LEFT);
	        table.addCell(c1);
	       
	        
	        
	        
	        table.addCell(userName);
	        table.addCell(policyName);
	        table.addCell(policyType);
	        table.addCell(policyCost);
	        
	         
	         
	        //setting company logo
	         Image image2 = Image.getInstance("logo.jpg");
	         
	         image2.scaleAbsolute(80f, 50f);
	         
	         
	         
	         
	         Paragraph summaryParagraph = new Paragraph("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem IpsumLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum");
	         
	         
	         
	         
	           
	         
	         document.add(companyName);
	         
	         
	         document.add(address);
	         document.add(contactDetails);
	         document.add(webDetails);
	         
	         
	         
	         
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         
	         
	         document.add(dateParagraph);
	         
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         
	         document.add(table);
	       
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         
	         document.add(summaryParagraph);
	         

	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         document.add(new Phrase("\n"));
	         
	         
	         
	         document.add(image2);	
	 
	    } 
		catch (Exception e){
			
	        e.printStackTrace();
	    }
		
		finally {
			//closing the file and writer object
	         document.close();
	         writer.close();
			
		}
		
	}
	
}
