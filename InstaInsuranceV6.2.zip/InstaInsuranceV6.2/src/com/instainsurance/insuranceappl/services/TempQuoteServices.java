package com.instainsurance.insuranceappl.services;

import java.util.List;

import com.instainsurance.insuranceappl.models.TempQuote;

public interface TempQuoteServices {
	Boolean insertTempQuote(TempQuote tempQuote);
	Boolean updateTempQuote(TempQuote tempQuote);
	Boolean deleteTempQuote(TempQuote tempQuote);
	TempQuote findByTempQuoteId(String id);
	List<TempQuote> getTempQuotes();
}
