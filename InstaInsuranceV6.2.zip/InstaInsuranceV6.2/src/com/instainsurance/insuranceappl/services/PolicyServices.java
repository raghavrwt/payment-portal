package com.instainsurance.insuranceappl.services;

import java.util.List;

import com.instainsurance.insuranceappl.models.Policy;

public interface PolicyServices {
	Boolean insertPolicy(Policy policy);
	Boolean updatePolicy(Policy policy);
	Boolean deletePolicy(Policy policy);
	Policy findByPolicyId(String id);
	List<Policy> getPolicies();
	List<Policy> getPolicies(String category);
}
