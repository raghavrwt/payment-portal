package com.instainsurance.insuranceappl.services;

import java.util.List;

import com.instainsurance.insuranceappl.models.Customer;
import com.instainsurance.insuranceappl.models.Vehicle;

public interface VehicleServices {
	Boolean insertVehicle(Vehicle vehicle);
	Boolean updateVehicle(Vehicle vehicle);
	Boolean deleteVehicle(Vehicle vehicle);
	Vehicle findByVehicleId(String id);
	List<Vehicle> getVehicles();
	
	
	public Vehicle findByVehicleCustomer(Customer id);
}
