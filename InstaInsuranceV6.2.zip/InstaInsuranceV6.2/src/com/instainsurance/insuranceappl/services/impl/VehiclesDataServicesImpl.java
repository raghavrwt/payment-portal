package com.instainsurance.insuranceappl.services.impl;

import javax.annotation.Resource;


import org.springframework.stereotype.Service;
import com.instainsurance.insuranceappl.daos.VehiclesDataDao;
import com.instainsurance.insuranceappl.models.VehiclesData;
import com.instainsurance.insuranceappl.services.VehiclesDataServices;


@Service("VehiclesDataServices")
public class VehiclesDataServicesImpl implements VehiclesDataServices {

	@Resource
	private VehiclesDataDao dao;
	
	@Override
	public Boolean insertVehicle(VehiclesData vehiclesData) {
		return dao.insertVehicleData(vehiclesData);
				
	}

	@Override
	public Boolean updateVehicle(VehiclesData vehiclesData) {
		return dao.updateVehicleData(vehiclesData);
	}

	@Override
	public Boolean deleteVehicle(VehiclesData vehiclesData) {
		return dao.deleteVehicleData(vehiclesData);
	}

	@Override
	public VehiclesData findByVehicleDataId(String id) {
		return dao.findByVehicleDataId(id);
	}
}
