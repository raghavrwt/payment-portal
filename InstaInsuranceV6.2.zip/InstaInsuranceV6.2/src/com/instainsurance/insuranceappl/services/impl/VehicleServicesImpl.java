package com.instainsurance.insuranceappl.services.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.instainsurance.insuranceappl.daos.VehicleDao;
import com.instainsurance.insuranceappl.daos.impl.VehicleDaoImpl;
import com.instainsurance.insuranceappl.models.Customer;
import com.instainsurance.insuranceappl.models.Vehicle;
import com.instainsurance.insuranceappl.services.VehicleServices;

@Service
public class VehicleServicesImpl implements VehicleServices {

	@Resource
	private VehicleDao dao;

	@Override
	public Boolean insertVehicle(Vehicle vehicle) {
		return dao.insertVehicle(vehicle);
	}

	@Override
	public Boolean updateVehicle(Vehicle vehicle) {
		return dao.updateVehicle(vehicle);
	}

	@Override
	public Boolean deleteVehicle(Vehicle vehicle) {
		return dao.deleteVehicle(vehicle);
	}

	@Override
	public Vehicle findByVehicleId(String id) {
		return dao.findByVehicleId(id);
	}

	@Override
	public List<Vehicle> getVehicles() {
		return dao.getVehicles();
	}

	@Override
	public Vehicle findByVehicleCustomer(Customer id) {
		
		return dao.findByVehicleCustomer(id);
	}

}
