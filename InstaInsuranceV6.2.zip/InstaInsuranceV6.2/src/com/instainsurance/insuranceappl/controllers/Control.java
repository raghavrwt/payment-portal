package com.instainsurance.insuranceappl.controllers;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.instainsurance.insuranceappl.models.Customer;
import com.instainsurance.insuranceappl.models.TempQuote;
import com.instainsurance.insuranceappl.models.Vehicle;
import com.instainsurance.insuranceappl.services.CustomerServices;
import com.instainsurance.insuranceappl.services.TempQuoteServices;
import com.instainsurance.insuranceappl.services.VehicleServices;



@Controller
public class Control {
	
	
@Autowired
CustomerServices customerService;

@Autowired
VehicleServices vehicleService;

@Autowired
TempQuoteServices  tempQuoteServices;


	
@RequestMapping(value = "/registerProcess", method = RequestMethod.GET)
public void addUser(HttpServletRequest request, HttpServletResponse response) {
	
String firstName= request.getParameter("firstName");
String lastName=request.getParameter("lastName");;
String gender = request.getParameter("gender");;
String password =request.getParameter("password");;
String dob= request.getParameter("dob");;
String email =request.getParameter("email");
String mobile =request.getParameter("contact");
Date date1 = null;
try {
	date1 = new SimpleDateFormat("yyyy-MM-dd").parse(dob);
} catch (ParseException e) {
	e.printStackTrace();
}
Customer customer = new Customer();
int counter = customerService.getCustomer().size();
String randomId="CUS"+ (++counter);
customer.setCustomerId(randomId);
customer.setCustomerDob(date1);
customer.setCustomerEmail(email);
customer.setCustomerGender(gender);
customer.setCustomerPassword(password);
customer.setCustomerMobNo(mobile);
customer.setCustomerFirstName(firstName);
customer.setCustomerLastName(lastName);
System.out.println(firstName + lastName + gender + password + dob + email + mobile);
if(customerService.insertCustomer(customer)) {
	try {
		System.out.println("customer addedd successfully");
		
		response.sendRedirect("http://localhost:8089/InstaInsuranceV6.2/index.html");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}else {

	try {
		
		System.out.println("registration is not successful");
		response.sendRedirect("http://localhost:8089/InstaInsuranceV6.2/errorPage.html");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

}



@RequestMapping(value = "/loginProcess", method = RequestMethod.GET)
public ModelAndView login(HttpServletRequest request, HttpServletResponse response) {
	
String userName= request.getParameter("userName");
String password=request.getParameter("password");
System.out.println(userName + password);
Customer customer = customerService.findByCustomerId(userName);


if(customer!=null &&  password.equals(customer.getCustomerPassword())) {
	
	
	TempQuote tempQuote = tempQuoteServices.findByTempQuoteId(customer.getCustomerEmail());

//	System.out.println(tempQuote.getCustomerFirstName());
	System.out.println("username exists");
	System.out.println("login successful");
	
	  HttpSession session=request.getSession();  
   
	
	ModelAndView model = new ModelAndView("dash");
	model.addObject(customer);
	   session.setAttribute("name",customer); 
	   session.setAttribute("customerId", customer.getCustomerId());
	if(tempQuote!=null) {
	model.addObject(tempQuote);
	   session.setAttribute("name",tempQuote);
	}
	return model;
	
}else {
	try {
		response.sendRedirect("http://localhost:8089/InstaInsuranceV6.2/errorPage.html");
	
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("user doesn't exists");
}


return null;


}





//  function mapping for application form 





@RequestMapping(value = "/applicationProcess", method = RequestMethod.GET)
public ModelAndView application(HttpServletRequest request, HttpServletResponse response) {
String firstName = request.getParameter("firstName");
String lastName= request.getParameter("lastName");
String dob= request.getParameter("dob");
String gender= request.getParameter("gender");
String address= request.getParameter("address");
String contact= request.getParameter("contact");
String email= request.getParameter("email");
String passportNo= request.getParameter("passportNo");
String maritalStatus= request.getParameter("maritalStatus");
String aadharNo=request.getParameter("aadharNo");

Customer customer = customerService.findByCustomerId(email);

customer.setCustomerAddress(address);
customer.setCustomerFirstName(firstName);
customer.setCustomerLastName(lastName);


Date date1 = null;
try {
	date1 = new SimpleDateFormat("yyyy-MM-dd").parse(dob);
} catch (ParseException e) {
	e.printStackTrace();
}

customer.setCustomerDob(date1);

customer.setCustomerGender(gender);
customer.setCustomerAddress(address);
customer.setCustomerMobNo(contact);
customer.setCustomerPassport(passportNo);
customer.setCustomerMaritalStatus(maritalStatus);
customer.setCustomerAadhaarNo(aadharNo);

customerService.updateCustomer(customer);
System.out.println(customer.getCustomerId());

String registrationNo= request.getParameter("registrationNo");
String age= request.getParameter("age");
String vehicleValue= request.getParameter("vehicleValue");
String vehicleType= request.getParameter("vehicleType");
String vehicleSeats= request.getParameter("vehicleSeats");
String plateNumber= request.getParameter("plateNumber");
String engineNumber= request.getParameter("engineNumber");
String manufacturer= request.getParameter("manufacturer");
String chasisNumber= request.getParameter("chasisNumber");
String model= request.getParameter("model");
String modelNumber= request.getParameter("modelNumber");
String fuel= request.getParameter("fuel");
String registrationPlace= request.getParameter("registrationPlace");

Vehicle vehicle = new Vehicle();


vehicle.setVehicleOldOrNew(age);
vehicle.setVehicleValue(vehicleValue);
vehicle.setVehicleType(vehicleType);
vehicle.setVehicleNoOfSeat(vehicleSeats);
vehicle.setVehicleManufacturer(manufacturer);
vehicle.setVehicleEngineNo(engineNumber);
vehicle.setVehicleChasisNo(chasisNumber);
vehicle.setVehicleNumber(plateNumber);
vehicle.setVehicleModel(model);
vehicle.setVehicleModelNumber(modelNumber);
vehicle.setVehicleFuel(fuel);
vehicle.setVehicleRegistrationPlace(registrationPlace);

vehicle.setCustomer(customer);

System.out.println("1" + customer.getCustomerId());

Vehicle v = vehicleService.findByVehicleCustomer(customer);

System.out.println("2"+  v);

if(v!=null) {
if(customer.getCustomerId().equals(v.getCustomer().getCustomerId())) {
	
	v.setVehicleOldOrNew(age);
	v.setVehicleValue(vehicleValue);
	v.setVehicleType(vehicleType);
	v.setVehicleNoOfSeat(vehicleSeats);
	v.setVehicleManufacturer(manufacturer);
	v.setVehicleEngineNo(engineNumber);
	v.setVehicleChasisNo(chasisNumber);
	v.setVehicleNumber(plateNumber);
	v.setVehicleModel(model);
	v.setVehicleModelNumber(modelNumber);
	v.setVehicleFuel(fuel);
	v.setVehicleRegistrationPlace(registrationPlace);
	vehicleService.updateVehicle(v);	
	System.out.println("data exists");
	
}

}
else {
	
	vehicle.setVehicleRegNo(registrationNo);
	vehicleService.insertVehicle(vehicle);
	System.out.println("data do not exists in both tables");
}
return null;
}




@RequestMapping("/removeSession")
public void removeSession(HttpSession session , HttpServletResponse response){
	session.invalidate();
	System.out.println("From removeSession: " + session.getId());
	System.out.println("Session invalidated.");
	try {
		response.sendRedirect("http://localhost:8089/InstaInsuranceV6.2/errorPage.html");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}


@RequestMapping("/homeDashBoard")
public ModelAndView homeDashBoard(HttpSession session , HttpServletResponse response , HttpServletRequest request){
	
	session = request.getSession(false);
	ModelAndView modelAndView =null;
	if(session!=null) {
	modelAndView = new ModelAndView("homeDashBoard");
	return modelAndView;
	}
	else {
		modelAndView = new ModelAndView("error");
		
		return modelAndView;
		
	}

}

@RequestMapping("/incident")
public ModelAndView incident(HttpSession session , HttpServletResponse response , HttpServletRequest request){
	

	session = request.getSession(false);
	ModelAndView modelAndView =null;
	if(session!=null) {
	modelAndView = new ModelAndView("incident");
	return modelAndView;
	}
	else {
		modelAndView = new ModelAndView("error");
		
		return modelAndView;
		
	}
}


@RequestMapping("/application")
public ModelAndView application(HttpSession session , HttpServletResponse response , HttpServletRequest request){
	
	session = request.getSession(false);
	ModelAndView modelAndView =null;
	if(session!=null) {
	modelAndView = new ModelAndView("dash");
	return modelAndView;
	}
	
	else {
		modelAndView = new ModelAndView("error");
		
		return modelAndView;
		
	}
}

@RequestMapping("/payment")
public ModelAndView payment(HttpSession session , HttpServletResponse response , HttpServletRequest request){
	
	session = request.getSession(false);
	ModelAndView modelAndView =null;
	if(session!=null) {
	modelAndView = new ModelAndView("payment");
	return modelAndView;
	}
	else {
		modelAndView = new ModelAndView("error");
		
		return modelAndView;
		
	}
}

@RequestMapping("/paymentPortal")
public ModelAndView paymentPortal(HttpSession session , HttpServletResponse response , HttpServletRequest request){
	
	session = request.getSession(false);
	ModelAndView modelAndView =null;
	if(session!=null) {

	modelAndView = new ModelAndView("paymentPortal");
	return modelAndView;
	}
	else {
		modelAndView = new ModelAndView("error");
		
		return modelAndView;
		
	}
}



@RequestMapping("/contact")
public ModelAndView contact(HttpSession session , HttpServletResponse response , HttpServletRequest request){
	
	session = request.getSession(false);
	ModelAndView modelAndView =null;
	if(session!=null) {

	modelAndView = new ModelAndView("contact");
	return modelAndView;
	}
	else {
		modelAndView = new ModelAndView("error");
		
		return modelAndView;
		
	}
}

}
