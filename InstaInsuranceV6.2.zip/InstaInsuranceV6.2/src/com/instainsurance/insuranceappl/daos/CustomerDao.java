package com.instainsurance.insuranceappl.daos;

import java.util.List;

import com.instainsurance.insuranceappl.models.Customer;

public interface CustomerDao {
	Boolean insertCustomer(Customer customer);
	Boolean updateCustomer(Customer customer);
	Boolean deleteCustomer(Customer customer);
	Customer findByCustomerId(String id);
	List<Customer> getCustomer();
	
//	public Customer checkLogin(String userName, String userPassword);
}
