package com.instainsurance.insuranceappl.daos;


import com.instainsurance.insuranceappl.models.VehiclesData;

public interface VehiclesDataDao {

	Boolean insertVehicleData(VehiclesData vehicledata);
	Boolean updateVehicleData(VehiclesData vehicledata);
	Boolean deleteVehicleData(VehiclesData vehicledata);
	VehiclesData findByVehicleDataId(String id);	
}
