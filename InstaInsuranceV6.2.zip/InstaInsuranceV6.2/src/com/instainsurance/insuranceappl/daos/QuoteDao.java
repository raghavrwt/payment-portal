package com.instainsurance.insuranceappl.daos;

import java.util.List;

import com.instainsurance.insuranceappl.models.Quote;

public interface QuoteDao {

	Boolean insertQuote(Quote quote);
	Boolean updateQuote(Quote quote);
	Boolean deleteQuote(Quote quote);
	Quote findByQuoteId(String id);
	List<Quote> getQuotes();
}
