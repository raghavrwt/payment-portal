package com.instainsurance.insuranceappl.daos;

import java.util.List;

import com.instainsurance.insuranceappl.models.Customer;
import com.instainsurance.insuranceappl.models.Vehicle;

public interface VehicleDao {

	Boolean insertVehicle(Vehicle vehicle);
	Boolean updateVehicle(Vehicle vehicle);
	Boolean deleteVehicle(Vehicle vehicle);
	Vehicle findByVehicleId(String id);
	List<Vehicle> getVehicles();
	public Vehicle findByVehicleCustomer(Customer id) ;
}
