
"use strict";

jQuery(document).ready(function($){


	// var x=$(window).width();
    // var y=$(window).height();
    // var a=x;
    // var b=y;

    // $(".banner").css('width', a);
    // $(".banner").css('height', b);



	/************** Nice Scroll Plugin *********************/
	$("html").niceScroll({
		cursorcolor : '#a71e2b',
		cursorborder : 0,
		zindex : 99999,
	});




	/************** Open Different Pages *********************/
	$(".main a").click(function(){
		var id =  $(this).attr('class');
		id = id.split('-');

		$('.banner .logo').hide();
		$("#menu-container .content").hide();
		$("#menu-container #menu-"+id[1]).slideDown(600);
		$("#menu-container .homepage").hide();
		return false;
		
	});

	$("#quote_button").click(function(){
		$('.banner .logo').hide();
		$("#menu-container .content").hide();
		$("#menu-container #menu-7").slideDown(600);
		$("#menu-container .homepage").hide();
		return false;
		
	});
	
	
	


	$("#get_quote").click(function(){
		$('.banner .logo').hide();
		$("#menu-container .content").hide();
		$("#menu-container #menu-6").slideDown(600);
		$("#menu-container .homepage").hide();
		return false;
		
	});



	$("#get_quote2").click(function(){
		$('.banner .logo').hide();
		$("#menu-container .content").hide();
		$("#menu-container #menu-6").slideDown(600);
		$("#menu-container .homepage").hide();
		return false;
		
	});



	$(".main a.homebutton").click(function(){
		$('.banner .logo').show();
		$("#menu-container .content").hide();
		$("#menu-container .homepage").hide();
		return false;
	});


});