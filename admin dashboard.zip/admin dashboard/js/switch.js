$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideDown("slow");
    });
});