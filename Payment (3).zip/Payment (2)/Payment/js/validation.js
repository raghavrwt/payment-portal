function validateForm() {
    var x = document.forms["myForm"]["firstName"].value;
    if (x == "") {
        document.getElementById('errorname').innerHTML ="First Name must be filled out";
        return false;
    }
    var reg=/^[a-zA-Z]*$/g;
    var x = document.forms["myForm"]["firstName"].value;
    if(reg.test(x) == false)
    {
     	document.getElementById('errorname').innerHTML = "Name should contain only alphabets";
    	return(false);
    }



    var x = document.forms["myForm"]["lastName"].value;
    if (x == "") {
       document.getElementById('errorname1').innerHTML ="Last Name must be filled out";
        return false;
    } 

    var reg=/^[a-zA-Z]*$/g;
    var x = document.forms["myForm"]["lastName"].value;
    if(reg.test(x) == false)
    {
     	document.getElementById('errorname1').innerHTML = "Name should contain only alphabets";
    	return(false);
    }

    var x = document.forms["myForm"]["address"].value;
    if (x == "") {
       document.getElementById('errorname2').innerHTML ="Address must be filled out";
        return false;
    }  
    
    var x = document.forms["myForm"]["mobileNo"].value;
    if (x == "") {
       document.getElementById('errorname3').innerHTML ="Passport Number must be filled out";
        return false;
    } 

    var reg=/^\d{10}$/;
    var x = document.forms["myForm"]["mobileNo"].value;
    if(reg.test(x) == false)
    {
        document.getElementById('errorname3').innerHTML = "Mobile Number should contain 10 digits";
    	return(false);
    }

    var x = document.forms["myForm"]["email"].value;
    if (x == "") {
       document.getElementById('errorname4').innerHTML ="Passport Number must be filled out";
        return false;
    } 

    var reg=/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    var x = document.forms["myForm"]["email"].value;
    if(reg.test(x) == false)
    {
     	document.getElementById('errorname4').innerHTML = "Email Address should be of the format xxxxx@xxxx.com";
    	return(false);
    }

    var x = document.forms["myForm"]["passportNo"].value;
    if (x == "") {
       document.getElementById('errorname5').innerHTML ="Passport Number must be filled out";
        return false;
    } 

    var reg= /^[A-PR-WY][1-9]\d\s?\d{4}[1-9]$/ig;
    var x = document.forms["myForm"]["passportNo"].value;
    if(reg.test(x) == false)
    {
     	document.getElementById('errorname5').innerHTML = "Please enter a valid passport number";
    	return(false);
    }


    var x = document.forms["myForm"]["aadharNo"].value;
    if (x == "") {
       document.getElementById('errorname6').innerHTML ="Aadhar Number must be filled out";
        return false;
    } 


    var reg=/^\d{12}$/;
    var x = document.forms["myForm"]["aadharNo"].value;
    if(reg.test(x) == false)
    {
        document.getElementById('errorname6').innerHTML = "Aadhar Number should contain 12 digits";
    	return(false);
    }

    else {
        return true;
    }
}